<script>
function createElements() {
  var ni = document.getElementById('myDiv');
  var numi = document.getElementById('theValue');
  var num = (document.getElementById("theValue").value -1)+ 2;
  numi.value = num;
  var divIdName = "my"+num+"Div";
  var newdiv = document.createElement('div');
  newdiv.setAttribute("id",divIdName);
  newdiv.innerHTML = "Nama &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;<input type = text name = nama" + num + "></td></tr> <a href=\"javascript:;\" onclick=\"removeElement(\'"+divIdName+"\')\">Hapus Donk</a>";
  ni.appendChild(newdiv);
}

function removeElement(divNum) {
  var d = document.getElementById('myDiv');
  var olddiv = document.getElementById(divNum);
  d.removeChild(olddiv);
}
</script>
<html>
<head>
<title>.:: Create Element View-Code.com ::.</title>
</head>
<body>
<?php
echo "<h3><a href=\"http://view-code.com\">Tambah ELement TextField</a></h3><br>";
echo "Input Data.";
echo "
<form method=POST name = masukin>
<table width=380 border=0>
  <tr>
    <td>Nama</td>
    <td width=280>: <input type=text name=nama1>
	</td>
  </tr>
  <tr>
    <td colspan=2></td>
  </tr>
  <tr>
  </tr><input value=\"1\" id=\"theValue\" type=\"hidden\" name = jml>
</table>
<div id=\"myDiv\"> </div>
<a href=\"javascript:;\" onclick=\"createElements();\">Tambah DOnk</a><br>
<input type=submit name=Submit value=Submit />
</form>";
if ($_GET[act]=='simpan'){
	//biar nama-nama yang kita submit di textfield terbaca
	echo "$_POST[nama]";
	echo "$_POST[tes]";
}
echo "<br><hr>";
echo "Keterangan!<br>";
?>
</body>
</html>

<?
	if(isset($_POST['Submit'])){
		include "koneksi.php";
		for($i = 1; $i<=$_POST[jml];$i++){
			if($_POST[nama.$i]!=""){
				echo "<br><br>";
				mysql_query("Insert into nama(nama) values('".$_POST[nama.$i]."')");
				echo "Data dengan nama ".$_POST[nama.$i]." dah masuk";
			}
		}
	}
?>
